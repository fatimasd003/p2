
#ifndef C_PROJECT_DRAW_H
#define C_PROJECT_DRAW_H
#include "my_struct.h"
#include "my_SDL.h"
#include <SDL2_gfxPrimitives.h>

void show_Barrack(struct Barrack b){
    int i;
    switch (b.type) {
        case ENEMY_TYPE: i=1;break;
        case MY_TYPE:i=2;break;
        case BLANK_TYPE:i=0;break;
    }
    Uint32 color =colors[i];
    Sint16 x =b.x , y =b.y , r = 20;
    boxColor(renderer,x-r,y-r,x+r,y+r,color);
    sprintf(buffer,"%d",b.soldier);
    stringRGBA(renderer,x-5,y,buffer,0,0,0,255);
}
void Draw(){
    for(int i=0;i<level.barracksCount;i++){
        show_Barrack(level.barracks[i]);
    }
}

void draw_rectangle(int i){
    SDL_Rect rect;
    rect.x=level.barracks[i].x-22;
    rect.y=level.barracks[i].y-22;
    rect.w=46;
    rect.h=46;
    int r = 255, g = 0, b = 255,a=255;
    SDL_SetRenderDrawColor(renderer, r, g, b,a);
    SDL_RenderDrawRect(renderer,&rect);
}
#endif //C_PROJECT_DRAW_H
