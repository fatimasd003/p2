
#ifndef C_PROJECT_FILE_H
#define C_PROJECT_FILE_H
#include <stdio.h>
#include <stdlib.h>
#include "my_struct.h"
void write_file(char s[]){
    FILE *fp;
    fp= fopen(s,"wb");
    if(!fp){
        printf("Error in opening file!\n");
        exit(1);
    }
    fwrite(&level,sizeof(struct Game_Level),1,fp);
    fclose(fp);
}
void reed_file(char s[]){
    FILE *fp;
    fp= fopen(s,"rb");
    if(!fp){
        printf("Error in open file!\n");
        exit(1);
    }
    fread(&level,sizeof(struct Game_Level),1,fp);
    fclose(fp);
}
void which_file(int flag){
    switch (flag) {
        case 0:reed_file("previous_game.bin");break;
        case 1:reed_file("file1.bin");break;
        case 2:reed_file("file2.bin");break;
        default:reed_file("file1.bin");break;
    }
}
void which_file_write(int flag){
    switch (flag) {
        case 0:write_file("previous_game.bin");break;
        case 1:write_file("file1.bin");break;
        case 2:write_file("file2.bin");break;
        default:write_file("file1.bin");break;
    }
}
#endif //C_PROJECT_FILE_H
