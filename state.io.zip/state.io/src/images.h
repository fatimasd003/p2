
#ifndef C_PROJECT_IMAGES_H
#define C_PROJECT_IMAGES_H
#include <string.h>
#include <stdbool.h>
#include <SDL.h>
#include "my_SDL.h"
void strcut_file_bmp(char name_file[],int count){
    char number[20][2]={"0","1","2","3","4","5","6","7","8","9",
                        "10","11","12","13","14","15","16","17","18","19"};
    strcat(name_file,number[count]);
    strcat(name_file,".bmp");
}
void image_number(char name_file[],int count){
    strcut_file_bmp(name_file,count);
    loadMedia(name_file);
}
bool gif(int *gif_h,int count,char name_file[],int speed){
    strcut_file_bmp(name_file,*gif_h);
    loadMedia(name_file);
    SDL_Delay(speed);
    (*gif_h)++;
    if(*gif_h<=count)
        return true;
    *gif_h=0;
    return false;
}
#endif //C_PROJECT_IMAGES_H
