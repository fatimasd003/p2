#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#ifdef main
#undef main
#endif

//header file
#include <SDL_main.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

//my header file
#include "my_struct.h"
#include "select.h"
#include "my_SDL.h"
#include "file.h"
#include "solders.h"
#include "my_time.h"
#include "draw.h"
#include "win_or_lose.h"
#include "my_color.h"
#include "set_setting.h"
#include "images.h"

#include <math.h>
void random_map(){
    srand(time(0));
    //printf("Enter tedad sarbaz khane ha: ");
    //scanf("%d",&level.barracksCount);
    level.barracksCount=(rand()%10)+6;
    int count=(rand()%(level.barracksCount-4))+1;
    //printf("Enter tedad doshman ha: ");
    //scanf("%d",&count);
    for (int i = 0; i < level.barracksCount; i++) {
        if(i<count)
            level.barracks[i].type=ENEMY_TYPE;
        else if(i==count)
            level.barracks[i].type=MY_TYPE;
        else {
            if(rand()%2)
                level.barracks[i].type=MY_TYPE;
            else
                level.barracks[i].type=BLANK_TYPE;
        }
        if(level.barracks[i].type==BLANK_TYPE)
            level.barracks[i].soldier=(rand()%30)+5;
        else
            level.barracks[i].soldier=(rand()%20)+1;
        level.barracks[i].max=(rand()%31)+25;

    }
    for (int i = 0; i < level.barracksCount; i++) {
        bool ok=true;
        int x=(rand()%600)+30;
        int y=(rand()%600)+30;
        double spase=(rand()%70)+50;
        for (int j = 0; j < i; j++) {
            if(sqrt(pow(x-level.barracks[j].x,2)+pow(y-level.barracks[j].y,2))<spase){
                ok=false;
                i--;
                break;
            }
        }
        if(ok){
            level.barracks[i].x=x;
            level.barracks[i].y=y;
        }
    }
}

int main(){
    random_map();
    if( !init() ){
        printf( "Failed to initialize!\n" );
    }else {
        //Struct for handling events
        SDL_Event input;
        //Boolean to find out whether the game is stopped or not Of course, it will be false at start
        bool quit = false;
        //For selecting renderer's draw color
        set();
        int startTicks = SDL_GetTicks();
        
        for (int i = 0; !quit; i++) {
            if(press_menu && !start_game && last_Select!=Select) {
                char name[20]="menu";
                image_number(name,Select);
                press_menu=false;
                last_Select=Select;
            }
            //---Event polling method---
            //It runs until the number of events to be polled gets to zero
            while (SDL_PollEvent(&input) > 0) {
                //If the user did something which should
                //result in quitting of the game then...
                switch (input.type) {
                    case SDL_QUIT:
                        quit = true;
                        break;
                    case SDL_MOUSEMOTION:
                        if(!start_game) {
                            Select = which_menu(input);
                            press_menu = true;
                        }
                        break;
                    case SDL_MOUSEBUTTONUP:
                        if (start_game) {
                            q = which_barrack(input);
                            if (q != -1) {
                                p++;
                                press = true;
                            }
                        } else {
                            int y = which_menu(input);
                            if(y==1)
                                start_game=true;
                            else if(y==2) {
                                which_file(0);
                                if (!win())
                                    start_game=true;
                                else
                                    which_file(1);
                            }
                        }
                        break;
                }
            }
            SDL_SetRenderDrawColor(renderer,my_color[WHITE].r, my_color[WHITE].g, my_color[WHITE].b, my_color[WHITE].a);
            SDL_RenderClear(renderer);

            if (start_game) {
                if (win()) {
                    loadMedia("win.bmp");
                    Exit++;
                }
                if (Exit < 1) {
                    if (sol[o].tu && press) {
                        sol[o].tu = choice(&p, &sol[o].m, &sol[o].k, &u, &sol[o].q1, &sol[o].q2, q);
                        press = false;
                    }
                    if (u) draw_rectangle(sol[o].q1);
                    if(!sol[o].tu && !u) {
                        o++;
                    }
                    for (int j = 0; j < 15; j++) {
                        if (!sol[j].tu) {
                            sol[j].tu = move(sol[j].s, sol[j].q1, sol[j].q2, &sol[j].m, &sol[j].k,
                                             &sol[j].count_solder);
                        }
                    }
                    for (int j = 0; j < 15; j++)
                        if (!sol[j].tu) {
                            SDL_Delay(100);
                            break;
                        }
                    if(o==15)
                        o=0;
                    Draw();
                    if (check_time(startTicks, timer)) {
                        add_solder();
                        startTicks = SDL_GetTicks();
                    }
                }
                if (Exit == 2) {
                    SDL_Delay(2000);
                    set();
                    which_file_write(0);
                    random_map();
                    //which_file(1);
                }
            }
            if(!start_game ||Exit==1 )
                SDL_RenderCopy(renderer, Texture, NULL, NULL);
            SDL_RenderPresent(renderer);
        }
        which_file_write(0);
    }
    close();
    return 0;
}

