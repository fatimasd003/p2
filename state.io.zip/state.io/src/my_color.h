//


#ifndef C_PROJECT_MY_COLOR_H
#define C_PROJECT_MY_COLOR_H
struct color{
    int r,g,b,a;
};
struct color my_color[10]={
        {0,0,0,1},
        {255,255,255,1},
        {0,0,0,1},
        {0,0,0,1},
        {0,0,0,1},
        {0,0,0,1},
        {0,0,0,1},
        {0,0,0,1},
        {0,0,0,1},
        {0,0,0,1},
};
enum colors1 {BLACK,WHITE};
#endif //C_PROJECT_MY_COLOR_H
