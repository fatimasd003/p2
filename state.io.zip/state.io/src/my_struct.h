
#ifndef C_PROJECT_MY_STRUCT_H
#define C_PROJECT_MY_STRUCT_H
#define ENEMY_TYPE 0
#define BLANK_TYPE -1
#define MY_TYPE 3
struct Barrack{
    int soldier;
    int type;
    int x;
    int y;
    int max;
};
struct Game_Level{
    int barracksCount;
    struct Barrack barracks[16];
};
struct Game_Level level={10,{
        {41,ENEMY_TYPE,60,60,70},
        {36,ENEMY_TYPE,510,570,65},
        {31,ENEMY_TYPE,560,90,60},
        {17,MY_TYPE,330,240,35},
        {9,MY_TYPE,90,600,25},
        {22,MY_TYPE,150,420,40},
        {29,BLANK_TYPE,120,270,55},
        {25,BLANK_TYPE,420,70,50},
        {21,BLANK_TYPE,360,510,45},
        {12,BLANK_TYPE,540,320,30}
}};
Uint32 colors[3]={0xffa3a9a1,0xff3383ff,0xffff333f};
char buffer[10];
#endif //C_PROJECT_MY_STRUCT_H
