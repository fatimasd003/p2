
#ifndef C_PROJECT_SELECT_H
#define C_PROJECT_SELECT_H
#include "SDL_events.h"
#include "my_struct.h"
int which_menu(SDL_Event input){
    if(input.button.x<=490 && input.button.x>=135) {
        if (input.button.y <= 290 && input.button.y >= 180)
            return 1;
        else if(input.button.y <= 435 && input.button.y >= 325)
            return 2;
        else if(input.button.y <= 570 && input.button.y >= 460)
            return 3;
    }
    return 0;
}
int which_barrack(SDL_Event input){
    int r=20;
    for (int i = 0; i < level.barracksCount; i++)
        if(input.button.x<=level.barracks[i].x+r && input.button.x>=level.barracks[i].x-r && input.button.y<=level.barracks[i].y+r && input.button.y>=level.barracks[i].y-r)
            return i;
    return -1;
}
#endif //C_PROJECT_SELECT_H
