
#ifndef C_PROJECT_SET_SETTING_H
#define C_PROJECT_SET_SETTING_H
#include "solders.h"
int q,p,o, Exit, Select,last_Select;
bool press ,u, start_game ,press_menu;
void set(){
    p = 0;
    Exit = 0;
    Select = 0;
    last_Select = 1;
    for (int i = 0; i < 15; i++) {
        sol[i].tu=true;
    }
    press = false;
    u = false;
    start_game = false;
    press_menu=true;
}
#endif //C_PROJECT_SET_SETTING_H
