
#ifndef C_PROJECT_WIN_OR_LOSE_H
#define C_PROJECT_WIN_OR_LOSE_H

#include "my_struct.h"
#include <stdbool.h>
bool win(){
    for (int i = 0; i < level.barracksCount; i++) {
        if(level.barracks[i].type==ENEMY_TYPE)
            return false;
    }

    return true;
}

#endif //C_PROJECT_WIN_OR_LOSE_H
