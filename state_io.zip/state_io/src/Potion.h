
#ifndef C_PROJECT_POTION_H
#define C_PROJECT_POTION_H
#include "my_time.h"
#include <time.h>
#include <SDL.h>
#include <stdlib.h>
#include "my_struct.h"
#include "solders.h"
#include <stdio.h>
#include "set_setting.h"

struct potion_on{
    bool on_off;
    int power;
    int x,y;
    int time;
}potion_[3];

void potion(){
    if (check_time(potionTicks,time_potion)){
    srand(SDL_GetTicks());
    for (int i = 0; i < 3; i++)
        if(!potion_[i].on_off) {
            int q1, q2;
            do { q1 = rand() % level.barracksCount; } while (level.barracks[q1].type==EMPTY_TYPE);
            do { q2 = rand() % level.barracksCount; } while (q1 == q2 || level.barracks[q2].type==EMPTY_TYPE);
            int d = (level.barracks[q1].y - level.barracks[q2].y), d2 = (level.barracks[q1].x - level.barracks[q2].x);
            int space=sqrt(pow(level.barracks[q1].x-level.barracks[q2].x,2)+pow(level.barracks[q2].y-level.barracks[q2].y,2));

            if(level.barracks[q1].x<level.barracks[q2].x)
                potion_[i].x=level.barracks[q1].x+((space/20)*10);
            else
                potion_[i].x=level.barracks[q1].x-((space/20)*10);

            double m = (double) d / (double) d2;//shib khat
            potion_[i].y = m * (potion_[i].x - level.barracks[q1].x) + level.barracks[q1].y;//moadele khat
            potion_[i].power = (rand() % 4) + 1;
            potion_[i].on_off = true;
            potion_[i].time = SDL_GetTicks();
            break;
        }
        time_potion=((rand()%20000)+15000);
        potionTicks = SDL_GetTicks();
    }
}
void draw_potion(){
    for (int i = 0; i < 3; i++)
        if(potion_[i].on_off){
            filledCircleColor(renderer, potion_[i].x,  potion_[i].y, 15, colors2[potion_[i].power]);
        }
}
bool find(struct Barrack s[],int m){
    for (int i = 0; i < m; i++)
        for (int j = 0; j < 3; j++) {
            int sp = sqrt(pow(s[i].x - potion_[j].x, 2) + pow(s[i].y - potion_[j].y, 2));
            if (s[i].type != EMPTY_TYPE && potion_[i].on_off && sp <= 20) {
                bool ok = true;
                for (int k = 0; k < level.barracksCount; k++)
                    if (s[i].type == level.barracks[k].type)
                        if (level.barracks[k].Potion != 0) {
                            ok = false;
                            break;
                        }
                if (ok) {
                    for (int k = 0; k < level.barracksCount; k++)
                        if (s[i].type == level.barracks[k].type) {
                            level.barracks[k].Potion = potion_[j].power;
                            level.barracks[k].start_potion = SDL_GetTicks();
                        }
                    potion_[j].on_off = false;
                    return true;
                }
                return false;
            }
        }
}
void find_() {
    int ok = false;
    for (int j = 0; j < 3; j++)
        if (potion_[j].on_off) {
            ok = true;
            break;
        }
    if(ok)
        for (int i = 0; i < 30; i++)
            if (sol[i].tu)
                find(sol[i].s, sol[i].m);
}
void clear(){
    for (int i = 0; i < 3; i++)
        potion_[i].on_off = false;
}

void clear_time(){
    for (int i = 0; i < 3; i++)
        if(potion_[i].on_off && check_time(potion_[i].time, 25000))
            potion_[i].on_off = false;
}

void End_time_potion(){
    for (int k = 0; k < level.barracksCount; k++)
        if (level.barracks[k].Potion!=0 && check_time(level.barracks[k].start_potion,20000))
                level.barracks[k].Potion = 0;
}

void set_time_to_now_potion(){
    for (int k = 0; k < level.barracksCount; k++)
        if (level.barracks[k].Potion!=0)
            level.barracks[k].start_potion=SDL_GetTicks();
}

void draw_time_potion(){
    for (int k = 0; k < level.barracksCount; k++)
        if (level.barracks[k].Potion!=0 && level.barracks[k].type==ENEMY_TYPE) {
            int x=640,y=10, end=SDL_GetTicks();
            for (int i=(end-level.barracks[k].start_potion)/100; i < 200; i++) {
                filledCircleColor(renderer, x--,  y, 4, colors2[level.barracks[k].Potion]);
            }
            break;
        }
    for (int k = 0; k < level.barracksCount; k++)
        if (level.barracks[k].Potion!=0 && level.barracks[k].type==MY_TYPE) {
            int x=10,y=10, end=SDL_GetTicks();
            for (int i=(end-level.barracks[k].start_potion)/100; i < 200; i++) {
                filledCircleColor(renderer, x++,  y, 4, colors2[level.barracks[k].Potion]);
            }
            break;
        }
}
void main_potion(){
    potion();
    draw_potion();
    clear_time();
    End_time_potion();
    draw_time_potion();
    find_();
}
#endif //C_PROJECT_POTION_H
