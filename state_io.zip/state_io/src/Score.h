
#ifndef C_PROJECT_SCORE_H
#define C_PROJECT_SCORE_H
#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#include <stdio.h>
#include <string.h>
#include "my_SDL.h"
#include "set_setting.h"
struct users{
    char name[20];
    int score;
}all_user[100];

int counter=0;

void show_list(){
    int x=20,y=20;
    char d[100];
    for (int i = 0; i<counter; i++) {
        sprintf(d,"name: %s & score : %d",all_user[i].name,all_user[i].score);
        stringRGBA(renderer, x, y,d, 0,0,0,255);
        y+=20;
        if(y>620){
            y=20;
            x=420;
        }
    }
}
void sort(){
    bool flag=true;
    while (flag) {
        flag = false;
        for (int i = 0; i < counter-1; i++)
            if(all_user[i+1].score>all_user[i].score){
                struct users t =all_user[i];
                all_user[i]=all_user[i+1];
                all_user[i+1]=t;
                flag=true;
            }
    }
}
bool CPU_name(char name[]){
    for (int i = 0; i < 5; i++)
        if(!strcmp(name,name_cpu[i]))
            return false;
    return true;
}
bool new_player(char name[]){
    for (int i = 0; i < counter; i++)
        if(!strcmp(name,all_user[i].name))
            return false;
    return true;
}
void set_new_player(char name[]){
    strcpy( all_user[counter].name,name);
    all_user[counter].score=0;
    counter++;
}
void set_score(char name[],int score){
    for (int i = 0; i < counter; i++)
        if(!strcmp(name,all_user[i].name)){
            all_user[i].score+=score;
            if(all_user[i].score<0)
                all_user[i].score=0;
            break;
        }
}
void in_file(){
    sort();
    FILE *fp;
    fp= fopen("score.bin","wb");
    if(!fp){
        printf("Error in opening file!\n");
        exit(1);
    }
    fwrite(&all_user,sizeof(struct users),100,fp);
    fclose(fp);
    fp= fopen("counter.bin","wb");
    if(!fp){
        printf("Error in opening file!\n");
        exit(1);
    }
    fwrite(&counter,sizeof(int),1,fp);
    fclose(fp);
}
void read_file_score(){
    FILE *fp;
    fp= fopen("score.bin","rb");
    if(!fp){
        printf("Error in opening file!\n");
        exit(1);
    }
    fread(&all_user,sizeof(struct users),100,fp);
    fclose(fp);
    fp= fopen("counter.bin","rb");
    if(!fp){
        printf("Error in opening file!\n");
        exit(1);
    }
    fread(&counter,sizeof(int),1,fp);
    fclose(fp);
}
#endif //C_PROJECT_SCORE_H
