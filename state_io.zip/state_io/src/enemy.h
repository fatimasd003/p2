
#ifndef C_PROJECT_ENEMY_H
#define C_PROJECT_ENEMY_H
#include "solders.h"
#include "set_setting.h"
void Enemy_move(int k) {
    int max = 0, e1, e2, min = 0;
    bool min_target = true,ok=false;
    for (int i = 0; i < level.barracksCount; i++) {
        if (level.barracks[i].type == ENEMY_TYPE && level.barracks[i].soldier > max) {
            max = level.barracks[i].soldier;
            e1 = i;
        } else if(level.barracks[i].type != EMPTY_TYPE && level.barracks[i].type != ENEMY_TYPE){
            if ( min_target) {
                min = level.barracks[i].soldier;
                min_target = false;
            }
            if (level.barracks[i].soldier <= min) {
                min = level.barracks[i].soldier;
                e2 = i;
                ok=true;
            }
        }
    }
    if(ok) {
        sol[k].tu = ON;
        sol[k].m = 0;
        sol[k].k = 0;
        sol[k].q1 = e1;
        sol[k].q2 = e2;
    }
}
#endif //C_PROJECT_ENEMY_H
