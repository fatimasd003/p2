#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#ifdef main
#undef main
#endif

//header file
#include <SDL_main.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

//my header file
#include "select.h"
#include "my_SDL.h"
#include "file.h"
#include "my_color.h"
#include "set_setting.h"
#include "images.h"
#include "mouse.h"
#include "main_of_game.h"
#include "Score.h"
int main(){
    if( !init() ){
        printf( "Failed to initialize!\n" );
    }else{
        //Struct for handling events
        SDL_Event input;
        //Boolean to find out whether the game is stopped or not Of course, it will be false at start
        bool quit = false;
        //For selecting renderer's draw color
        set();//set need setting
        int gif_h=10;
        read_file_score();
        while (!quit) {
            //---Event polling method---
            //It runs until the number of events to be polled gets to zero
            while (SDL_PollEvent(&input) > 0) {
                //If the user did something which should
                //result in quitting of the game then...
                switch (input.type) {
                    case SDL_QUIT:
                        quit = true; break;
                    case SDL_MOUSEMOTION:
                        if(user_)
                            mouse_move(input); break;
                    case SDL_MOUSEBUTTONUP:
                        if(user_)
                            mouse_button(input); break;
                    case SDL_KEYDOWN:
                        if(!user_ && !gif_) {
                            if (input.key.keysym.sym == SDLK_RETURN || input.key.keysym.sym == SDLK_KP_ENTER) {
                                if (CPU_name(my_user)) {
                                    user_ = true;
                                    if (new_player(my_user))
                                        set_new_player(my_user);
                                }
                            } else if (input.key.keysym.sym == SDLK_BACKSPACE && te != 0) {
                                te--;
                                my_user[te] = '\0';
                            }
                        }
                        break;
                    case SDL_TEXTINPUT:
                        if(!user_ && !gif_) {
                            my_user[te] = *input.text.text;
                            te++;
                            my_user[te] = '\0';
                        }
                        break;
                }
            }
            stringRGBA(renderer, 10, 10, my_user, 0,0,0,255);
            SDL_SetRenderDrawColor(renderer,my_color[WHITE].r, my_color[WHITE].g, my_color[WHITE].b, my_color[WHITE].a);
            SDL_RenderClear(renderer);
            game();//play game
            if(score_menu)
                show_list();
            if((!start_game || Exit==1) && !score_menu)
                SDL_RenderCopy(renderer, Texture, NULL, NULL);

            if(gif_)
                gif_=gif(&gif_h,19,"gif",150);
            else if(user_)
                uplode_photo();
            else if(te!=0)
                stringRGBA(renderer, 325, 325,my_user, 255,255,255,255);

            SDL_RenderPresent(renderer);
        }
        which_file_write(0);//save game for continue
        in_file();

    }
    close();//close SDL
    return 0;
}