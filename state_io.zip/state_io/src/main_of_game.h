
#ifndef C_PROJECT_MAIN_OF_GAME_H
#define C_PROJECT_MAIN_OF_GAME_H
#include "solders.h"
#include "my_time.h"
#include "draw.h"
#include "win_or_lose.h"
#include "set_setting.h"
#include "images.h"
#include "enemy.h"
#include "file.h"
#include "clash_solder.h"
#include "Potion.h"
#include <conio.h>

void game(){
    if (start_game) {
        if(win()){
            loadMedia("win.bmp");
            W=true;
            Exit++;
        }
        if(Lose()){
            loadMedia("lose.bmp");
            W=false;
            Exit++;
        }

        if (Exit < 1) {
            for (int j = 0; j < 15; j++)
                if (sol[j].tu && p==1)
                    if(sol[j].q1==q) {
                        press = false;
                        p=0;
                    }
            if (!sol[my].tu && press) {
                sol[my].tu = choice(&p, &sol[my].m, &sol[my].k, &u, &sol[my].q1, &sol[my].q2, q);
                if(sol[my].tu)
                    my++;
                press = false;
            }
            if (u) draw_rectangle(sol[my].q1);

            if (check_time(EnemyTicks,time_enemy)){
                Enemy_move(ene);
                ene++;
                time_enemy=((rand()%12000)+3000);
                EnemyTicks = SDL_GetTicks();
            }

            for (int j = 0; j < 30; j++)
                if (sol[j].tu)
                    sol[j].tu = move(sol[j].s, sol[j].q1, sol[j].q2, &sol[j].m, &sol[j].k,&sol[j].count_solder,j);

            clash_k();
            for (int i = 0; i < 30; i++) {
                if (sol[i].tu) {
                    int emp=0;
                    for (int j = 0; j < sol[i].count_solder; j++) {
                        if (sol[i].s[j].type == EMPTY_TYPE)
                            emp++;
                    }
                    if(emp==sol[i].count_solder)
                        sol[i].tu=false;
                }
            }

            main_potion();

            for (int j = 0; j < 30; j++)
                if (sol[j].tu) {
                    SDL_Delay(20);
                    break;
                }

            if(my==15) my=0;
            if(ene=30) ene=15;

            Draw();

            if (check_time(startTicks, 3000)) {
                add_solder();
                startTicks = SDL_GetTicks();
            }

        }
        if (Exit == 2) {
            if(W) {
                set_score(my_user, 50);
                set_score(name_cpu[rand() % 5], -50);
            }
            else{
                set_score(my_user,-50);
                set_score(name_cpu[rand()%5],50);
            }
            SDL_Delay(3000);
            set();
            clear();
            which_file_write(0);
            sort();
        }
    }
    else{
        EnemyTicks = startTicks = potionTicks = SDL_GetTicks();
    }
}
#endif //C_PROJECT_MAIN_OF_GAME_H
