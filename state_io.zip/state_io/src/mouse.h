
#ifndef C_PROJECT_MOUSE_H
#define C_PROJECT_MOUSE_H
#include "set_setting.h"
#include "select.h"
#include "map.h"
#include "win_or_lose.h"
#include <stdio.h>
#include "Potion.h"
#include "Score.h"
void mouse_move(SDL_Event input){
    if (!start_game) {
        if(start_menu1)
            Select = which_maps_menu(input);
        else if (start_menu)
            Select = which_start_menu(input);
        else
            Select = which_menu(input);
        press_menu = true;
    }
}
void mouse_button(SDL_Event input){
    if (start_game) {
        q = which_barrack(input);
        if (q != -1) {
            p++;
            press = true;
        }
    }
    else if(start_menu1){
        int y = which_maps_menu(input);
        if(y!=7) {
            which_file(y - 7);
            start_game = true;
        }
    }
    else if(start_menu){
        int y = which_start_menu(input);
        if(y==5) {
            start_menu1= true;
        }
        else if(y==6) {
            random_map();
            start_game = true;
        }
    }
    else {
        int y = which_menu(input);
        if(y==1)
            start_menu=true;
        else if(y==2) {
            if(which_file(0)) {
                set_time_to_now_potion();
                if (not_win_or_lose())
                    start_game = true;
            }
        }
        else if(y==3){
            score_menu=true;
        }
    }
}
#endif //C_PROJECT_MOUSE_H
