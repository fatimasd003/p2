
#ifndef C_PROJECT_MY_TIME_H
#define C_PROJECT_MY_TIME_H
#include <SDL.h>
#include <stdbool.h>
bool check_time(int start,int time){
    int end=SDL_GetTicks();
    if(end-start>time)
        return true;
    return false;
}
#endif //C_PROJECT_MY_TIME_H
