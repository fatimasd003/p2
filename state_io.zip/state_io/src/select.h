
#ifndef C_PROJECT_SELECT_H
#define C_PROJECT_SELECT_H
#include "SDL_events.h"
#include "my_struct.h"
int which_menu(SDL_Event input){
    if(input.button.x<=490 && input.button.x>=135) {
        if (input.button.y <= 290 && input.button.y >= 180)
            return 1;
        else if(input.button.y <= 435 && input.button.y >= 325)
            return 2;
        else if(input.button.y <= 570 && input.button.y >= 460)
            return 3;
    }
    return 0;
}
int which_start_menu(SDL_Event input){
    if(input.button.x<=560 && input.button.x>=70) {
        if (input.button.y <= 275 && input.button.y >= 135)
            return 5;
        else if(input.button.y <= 500 && input.button.y >= 355)
            return 6;
    }
    return 4;
}
int which_maps_menu(SDL_Event input){
    if(input.button.x<=295 && input.button.x>=80) {
        if (input.button.y <= 190 && input.button.y >= 125)
            return 8;
        else if(input.button.y <= 315 && input.button.y >= 250)
            return 10;
        else if(input.button.y <= 450 && input.button.y >= 385)
            return 12;
        else if(input.button.y <= 570 && input.button.y >= 505)
            return 14;
    }
    else if(input.button.x<=560 && input.button.x>=345) {
        if (input.button.y <= 190 && input.button.y >= 125)
            return 9;
        else if(input.button.y <= 315 && input.button.y >= 250)
            return 11;
        else if(input.button.y <= 450 && input.button.y >= 385)
            return 13;
        else if(input.button.y <= 570 && input.button.y >= 505)
            return 15;
    }
    return 7;
}
int which_barrack(SDL_Event input){
    int r=20;
    for (int i = 0; i < level.barracksCount; i++)
        if(level.barracks[i].type!=EMPTY_TYPE && input.button.x<=level.barracks[i].x+r && input.button.x>=level.barracks[i].x-r && input.button.y<=level.barracks[i].y+r && input.button.y>=level.barracks[i].y-r)
            return i;
    return -1;
}
#endif //C_PROJECT_SELECT_H
