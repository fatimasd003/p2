
#ifndef C_PROJECT_SOLDERS_H
#define C_PROJECT_SOLDERS_H
#include <stdbool.h>
#include "my_struct.h"
#include "my_SDL.h"
#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#include "my_color.h"
#include <math.h>
#include "my_time.h"
#define ON true
#define OFF false

struct solders{
    bool tu;
    int q1,q2;
    int m,k;
    int count_solder;
    int time;
    struct Barrack s[100];
}sol[30];
int pppp=0,eeee=0;
void add_solder(){
    for (int i = 0; i < level.barracksCount; i++) {
        if(level.barracks[i].type!=BLANK_TYPE && (level.barracks[i].soldier<level.barracks[i].max || level.barracks[i].Potion==3))
            if(level.barracks[i].Potion==4)
                level.barracks[i].soldier+=2;
            else
                level.barracks[i].soldier++;
    }
}
void create_solder(struct Barrack a,struct Barrack b[],int m){
    b[m].x=a.x;
    b[m].y=a.y;
    b[m].type=a.type;
}
void show_solder(struct Barrack b[],int m){
    int h;
    for (int i = 0; i < m; i++) {
        switch (b[i].type) {
            case BLANK_TYPE:h = 0;break;
            case ENEMY_TYPE:h = 1;break;
            case MY_TYPE:h = 2;break;
        }
        Sint16 x = b[i].x, y = b[i].y, r = 6;
        if(b[i].type!=EMPTY_TYPE)
            filledCircleColor(renderer, x, y, r, colors[h]);
    }
}
void move_solder(struct Barrack a,struct Barrack a2,struct Barrack b[],int m) {
    int fx = a.x - a2.x, fy = a.y - a2.y;
    if (fx < 0)fx *= -1;
    if (fy < 0)fy *= -1;
    for (int i = 0; i < m; i++) {
        if ((100 < fx || 50 > fy) && (b[i].x != a2.x)) {
            if (b[i].x < a2.x)
                b[i].x += 10;
            else
                b[i].x -= 10;
            int d = (a.y - a2.y), d2 = (a.x - a2.x);
            double m = (double) d / (double) d2;//shib khat
            b[i].y = m * (b[i].x - a.x) + a.y;//moadele khat

        } else if (b[i].y != a2.y) {
            if (b[i].y < a2.y)
                b[i].y += 10;
            else
                b[i].y -= 10;
            int d = (a.y - a2.y), d2 = (a.x - a2.x);
            double m = (double) d / (double) d2;//shib khat
            double f = (double) (b[i].y - a.y) / m;//moadele khat
            b[i].x = f + a.x;
        }
        if(sqrt(pow(b[i].x-a2.x,2)+pow(b[i].y-a2.y,2))<20){
            b[i].y=a2.y;
            b[i].x=a2.x;
        }
    }
}


bool move(struct Barrack s[],int q1,int q2,int *m,int *k,int *h,int Y){
    if(*m==0)
        *h = level.barracks[q1].soldier;

    create_solder(level.barracks[q1], s, *m);

    bool on=OFF;
    int B=120;
    if(level.barracks[q1].Potion==1)
       B-=50;

    for (int i = 0; i < level.barracksCount; i++) {
       if(level.barracks[i].type!=level.barracks[q1].type && level.barracks[i].Potion==2) {
           B -= 50;
           break;
       }
    }

    if (check_time(sol[Y].time, B)) {
        on = ON;
        sol[Y].time = SDL_GetTicks();
    }

    if(on) {
        if(*m<*h) {
            level.barracks[q1].soldier--;
            (*m)++;
        }

        move_solder(level.barracks[q1], level.barracks[q2], s, *m);

        int fx = level.barracks[q2].x - s[*k].x, fy = level.barracks[q2].y - s[*k].y;
        if (fx < 0)fx *= -1;
        if (fy < 0)fy *= -1;

        if (10 > fx && 10 > fy) {
            if (s[*k].type != EMPTY_TYPE) {
                if (s[*k].type == level.barracks[q2].type)
                    level.barracks[q2].soldier++;
                else {
                    level.barracks[q2].soldier--;
                }
            }
            if (level.barracks[q2].soldier <= 0) {
                level.barracks[q2].soldier = 1;
                level.barracks[q2].type = level.barracks[q1].type;
                level.barracks[q2].Potion=level.barracks[q1].Potion;
                level.barracks[q2].start_potion=level.barracks[q1].start_potion;
            }
            (*k)++;
        }
    }

    show_solder(s, *m);
    if(*k==*h)
        return OFF;
    else
        return ON;
}
bool choice(int *p,int *m,int *k,bool *u,int *q1,int *q2,int q){
    if (*p == 1) {
        *q1 = q;
        if (level.barracks[*q1].type!=MY_TYPE)
            *p = 0;
        else
            *u = true;
    } else if (*p == 2) {
        *q2 = q;
        *p = 0;
        *u = false;
        *m = 0;
        *k = 0;
        if (*q1 != *q2)
            return ON;
    }
    return OFF;
}
#endif //C_PROJECT_SOLDERS_H
