
#ifndef C_PROJECT_CLASH_SOLDER_H
#define C_PROJECT_CLASH_SOLDER_H
#include "my_struct.h"
#include "solders.h"
#include <math.h>
void clash_k() {
    for (int i = 0; i < 15; i++)
        if (sol[i].tu)
            for (int h = 15; h < 30; h++)
                if (sol[h].tu)
                    for (int j = sol[i].m-1; j > 0; j--)
                        for (int k = sol[h].m; k > 0; k--)
                            if (sqrt(pow(sol[i].s[k].x - sol[h].s[j].x, 2) + pow(sol[i].s[k].y - sol[h].s[j].y, 2)) < 11) {
                                sol[i].s[k].type = EMPTY_TYPE;
                                sol[h].s[j].type = EMPTY_TYPE;
                                //return true;
                            }
}
#endif //C_PROJECT_CLASH_SOLDER_H
