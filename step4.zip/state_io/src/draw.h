
#ifndef C_PROJECT_DRAW_H
#define C_PROJECT_DRAW_H
#include "my_struct.h"
#include "my_SDL.h"
#include "my_color.h"
#include <SDL2_gfxPrimitives.h>
void show_Barrack(struct Barrack b){
    int i;
    switch (b.type) {
        case BLANK_TYPE:i=0;break;
        case ENEMY_TYPE: i=1;break;
        case MY_TYPE:i=2;break;
        case EMPTY_TYPE:i=0;
    }
    Sint16 x =b.x , y =b.y , r = 20,r2=40;
    boxColor(renderer,x-r2,y-r2,x+r2,y+r2,colors[i+3]);
    if(b.type!=EMPTY_TYPE) {
        boxColor(renderer, x - r, y - r, x + r, y + r, colors[i]);
        sprintf(buffer, "%d", b.soldier);
        stringRGBA(renderer, x - 5, y, buffer, 0, 0, 0, 255);
    }
}
void Draw(){
    for(int i=0;i<level.barracksCount;i++)
        show_Barrack(level.barracks[i]);
}
void draw_rectangle(int i){
    SDL_Rect rect;
    rect.x=level.barracks[i].x-22;
    rect.y=level.barracks[i].y-22;
    rect.w=46;
    rect.h=46;
    SDL_SetRenderDrawColor(renderer, my_color[RED].r, my_color[RED].g, my_color[RED].b,my_color[RED].a);
    SDL_RenderDrawRect(renderer,&rect);
}
#endif //C_PROJECT_DRAW_H
