
#ifndef C_PROJECT_FILE_H
#define C_PROJECT_FILE_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "my_struct.h"
void write_file(char s[]){
    FILE *fp;
    fp= fopen(s,"wb");
    if(!fp){
        printf("Error in opening file!\n");
        exit(1);
    }
    fwrite(&level,sizeof(struct Game_Level),1,fp);
    fclose(fp);
}
void reed_file(char s[]){
    FILE *fp;
    fp= fopen(s,"rb");
    if(!fp){
        printf("Error in open file!\n");
        exit(1);
    }
    fread(&level,sizeof(struct Game_Level),1,fp);
    fclose(fp);
}
void file_bin(char file[],int count){
    char number[10][2]={"0","1","2","3","4","5","6","7","8","9"};
    if(count>9){
        strcat(file,number[count/10]);
        strcat(file,number[count%10]);
    }
    else
        strcat(file,number[count]);
    strcat(file,".bin");
}
void which_file(int flag){
    if(flag==0)
        reed_file("previous_game.bin");
    else{
        char file[50]="file";
        file_bin(file,flag);
        reed_file(file);
    }
}

void which_file_write(int flag){
    if(flag==0)
        write_file("previous_game.bin");
    else{
        char file[50]="file";
        file_bin(file,flag);
        write_file(file);
    }
}
#endif //C_PROJECT_FILE_H
