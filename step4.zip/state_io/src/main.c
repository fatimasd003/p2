#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#ifdef main
#undef main
#endif

//header file
#include <SDL_main.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

//my header file
#include "select.h"
#include "my_SDL.h"
#include "file.h"
#include "my_color.h"
#include "set_setting.h"
#include "images.h"
#include "mouse.h"
#include "main_of_game.h"

int main(){
    if( !init() ){
        printf( "Failed to initialize!\n" );
    }else{
        //Struct for handling events
        SDL_Event input;
        //Boolean to find out whether the game is stopped or not Of course, it will be false at start
        bool quit = false;
        //For selecting renderer's draw color
        set();//set need setting
        while (!quit) {
            uplode_photo();
            //---Event polling method---
            //It runs until the number of events to be polled gets to zero
            while (SDL_PollEvent(&input) > 0) {
                //If the user did something which should
                //result in quitting of the game then...
                switch (input.type) {
                    case SDL_QUIT: quit = true; break;
                    case SDL_MOUSEMOTION: mouse_move(input); break;
                    case SDL_MOUSEBUTTONUP: mouse_button(input); break;
                }
            }
            SDL_SetRenderDrawColor(renderer,my_color[WHITE].r, my_color[WHITE].g, my_color[WHITE].b, my_color[WHITE].a);
            SDL_RenderClear(renderer);
            game();//play game
            if(!start_game || Exit==1 )
                SDL_RenderCopy(renderer, Texture, NULL, NULL);
            SDL_RenderPresent(renderer);
        }
        which_file_write(0);//save game for continue

    }
    close();//close SDL
    return 0;
}