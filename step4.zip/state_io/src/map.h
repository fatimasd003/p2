

#ifndef C_PROJECT_MAP_H
#define C_PROJECT_MAP_H
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include "my_struct.h"
void random_map(){
    srand(SDL_GetTicks());
    level.barracksCount=(rand()%14)+6;
    int count=(rand()%(level.barracksCount/2))+1;
    for (int i = 0; i < level.barracksCount; i++) {
        if(i<count)
            level.barracks[i].type=ENEMY_TYPE;
        else if(i==count)
            level.barracks[i].type=MY_TYPE;
        else {
            switch (rand()%3) {
                case 0:level.barracks[i].type=MY_TYPE;break;
                case 1:level.barracks[i].type=BLANK_TYPE;break;
                case 2:level.barracks[i].type=EMPTY_TYPE;break;

            }
        }
        if(level.barracks[i].type==BLANK_TYPE)
            level.barracks[i].soldier=(rand()%30)+5;
        else
            level.barracks[i].soldier=(rand()%20)+1;
        level.barracks[i].max=(rand()%31)+25;

    }
    for (int i = 0; i < level.barracksCount; i++) {
        bool ok=true;
        int x=(rand()%570)+40;
        int y=(rand()%550)+60;
        double spase=(rand()%70)+110;
        for (int j = 0; j < i; j++)
            if(sqrt(pow(x-level.barracks[j].x,2)+pow(y-level.barracks[j].y,2))<spase){
                ok=false;
                i--;
                break;
            }
        if(ok){
            level.barracks[i].x=x;
            level.barracks[i].y=y;
        }
    }
}
#endif //C_PROJECT_MAP_H
