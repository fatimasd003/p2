
#ifndef C_PROJECT_MY_SDL_H
#define C_PROJECT_MY_SDL_H
#include <SDL.h>
#include <SDL_image.h>
#include <stdbool.h>
#include <stdio.h>
const int SCREEN_WIDTH = 650;
const int SCREEN_HEIGHT = 650;
//Loads individual image as texture
SDL_Texture* loadTexture( char path[] );
//The window we'll be rendering to
SDL_Window* window = NULL;
//The window renderer
SDL_Renderer* renderer = NULL;
//Current displayed texture
SDL_Texture* Texture = NULL;

bool init(){
    //Initialization flag
    bool success = true;
    //Initialize SDL
    if( SDL_Init( SDL_INIT_EVERYTHING ) < 0 ){
        printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
        success = false;
    }
    else{
        //Set texture filtering to linear
        if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) ){
            printf( "Warning: Linear texture filtering not enabled!" );
        }
        //Create window
        window = SDL_CreateWindow( "State.io", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
        if( window == NULL ){
            printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
            success = false;
        }
        else{
            //Create renderer for window
            renderer = SDL_CreateRenderer( window, -1, SDL_RENDERER_ACCELERATED );
            if( renderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
            else{
                //Initialize renderer color
                SDL_SetRenderDrawColor( renderer, 0xFF, 0xFF, 0xFF, 0xFF );
            }
        }
    }
    return success;
}
SDL_Texture* loadTexture( char path[] ){
    //The final texture
    SDL_Texture* newTexture = NULL;
    //Load image at specified path
    SDL_Surface* loadedSurface = SDL_LoadBMP( path );
    if( loadedSurface == NULL ){
        printf( "Unable to load image %s! SDL_image Error: %s\n", path, IMG_GetError() );
    }
    else{
        //Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( renderer, loadedSurface );
        if( newTexture == NULL ){
            printf( "Unable to create texture from %s! SDL Error: %s\n", path, SDL_GetError() );
        }
        //Get rid of old loaded surface
        SDL_FreeSurface( loadedSurface );
    }
    return newTexture;
}
bool loadMedia(char s[]){
    //Loading success flag
    bool success = true;
    //Load PNG texture
    Texture = loadTexture( s );
    if( Texture == NULL ){
        printf( "Failed to load texture image!\n" );
        success = false;
    }
    return success;
}
void close(){
    //Free loaded image
    SDL_DestroyTexture( Texture );
    Texture = NULL;
    //Destroy window
    SDL_DestroyRenderer( renderer );
    SDL_DestroyWindow( window );
    window = NULL;
    renderer = NULL;
    //Quit SDL subsystems
    //IMG_Quit();
    SDL_Quit();
}
#endif //C_PROJECT_MY_SDL_H
