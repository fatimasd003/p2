//


#ifndef C_PROJECT_MY_COLOR_H
#define C_PROJECT_MY_COLOR_H
struct color{
    int r,g,b,a;
};
struct color my_color[10]={
        {255,255,255,1},
        {255,0,0,1},
        {0,255,0,1},
        {0,0,255,1},
        {0,128,128,1},
        {128,128,0,1},
        {128,0,128,1},
        {255,255,255,1},
        {255,0,0,1},
        {0,0,0,1},
};
Uint32 colors[10]={0xffa3a9a1,0xff3383ff,0xffff333f,0x64a3a9a1,0x643383ff,0x64ff333f,0x00000000,0xffffffff,};
Uint32 colors2[10]={0xffffffff,0xfff2c80f,0xff026645,0xff5c0001,0xff750985};
enum colors1 {GRAY,ORANGE,BLUE,PELE_BLUE,PELE_GRAY,PELE_ORANGE,BLACK,WHITE,RED};
#endif //C_PROJECT_MY_COLOR_H
