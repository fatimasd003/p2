
#ifndef C_PROJECT_MY_STRUCT_H
#define C_PROJECT_MY_STRUCT_H
#define ENEMY_TYPE 0
#define BLANK_TYPE -1
#define MY_TYPE 3
#define EMPTY_TYPE 4
struct Barrack{
    int soldier;
    int type;
    int x;
    int y;
    int max;

    int start_potion;
    int Potion;
};
struct Game_Level{
    int barracksCount;
    struct Barrack barracks[20];
}level;
char buffer[10];
#endif //C_PROJECT_MY_STRUCT_H
