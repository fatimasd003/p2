
#ifndef C_PROJECT_SET_SETTING_H
#define C_PROJECT_SET_SETTING_H
#include "my_struct.h"
#include "solders.h"
int q,p,my,ene, Exit, Select,last_Select;
bool press ,u, start_game ,start_menu,start_menu1,press_menu;
int startTicks, EnemyTicks,time_enemy,potionTicks,time_potion;

void set(){
    my=0;
    ene=15;
    p = 0;
    Exit = 0;
    Select = 0;
    last_Select = 1;
    time_enemy=10000;
    time_potion=20000;
    for (int i = 0; i < 30; i++) {
        sol[i].tu=false;
        sol[i].time=0;
    }
    press = false;
    u = false;
    start_game = false;
    start_menu = false;
    start_menu1 = false;
    press_menu=true;
}
#endif //C_PROJECT_SET_SETTING_H
