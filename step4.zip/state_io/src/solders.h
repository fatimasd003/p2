
#ifndef C_PROJECT_SOLDERS_H
#define C_PROJECT_SOLDERS_H
#include <stdbool.h>
#include "my_struct.h"
#include "my_SDL.h"
#include <SDL.h>
#include <SDL2_gfxPrimitives.h>
#include "my_color.h"
#include <math.h>
#include "my_time.h"
#define ON true
#define OFF false

struct solders{
    bool tu;
    int q1,q2;
    int m,k;
    int count_solder;
    int time;
    struct Barrack s[100];
}sol[30];
int pppp=0,eeee=0;
void add_solder(){
    for (int i = 0; i < level.barracksCount; i++) {
        if(level.barracks[i].type!=BLANK_TYPE && (level.barracks[i].soldier<level.barracks[i].max || level.barracks[i].Potion==3))
            if(level.barracks[i].Potion==4)
                level.barracks[i].soldier+=2;
            else
                level.barracks[i].soldier++;
    }
}
void create_solder(struct Barrack a,struct Barrack b[],int m){
    b[m].x=a.x;
    b[m].y=a.y;
    b[m].type=a.type;
}
void show_solder(struct Barrack b[],int m){
    int h;
    for (int i = 0; i < m; i++) {
        switch (b[i].type) {
            case BLANK_TYPE:h = 0;break;
            case ENEMY_TYPE:h = 1;break;
            case MY_TYPE:h = 2;break;
        }
        Sint16 x = b[i].x, y = b[i].y, r = 6;
        if(b[i].type!=EMPTY_TYPE)
            filledCircleColor(renderer, x, y, r, colors[h]);
    }
}
void move_solder(struct Barrack a,struct Barrack a2,struct Barrack b[],int m) {
    int fx = a.x - a2.x, fy = a.y - a2.y;
    if (fx < 0)fx *= -1;
    if (fy < 0)fy *= -1;
    for (int i = 0; i < m; i++) {
        if ((100 < fx || 50 > fy) && (b[i].x != a2.x)) {
            if (b[i].x < a2.x)
                b[i].x += 10;
            else
                b[i].x -= 10;
            int d = (a.y - a2.y), d2 = (a.x - a2.x);
            double m = (double) d / (double) d2;//shib khat
            b[i].y = m * (b[i].x - a.x) + a.y;//moadele khat

        } else if (b[i].y != a2.y) {
            if (b[i].y < a2.y)
                b[i].y += 10;
            else
                b[i].y -= 10;
            int d = (a.y - a2.y), d2 = (a.x - a2.x);
            double m = (double) d / (double) d2;//shib khat
            double f = (double) (b[i].y - a.y) / m;//moadele khat
            b[i].x = f + a.x;
        }
        if(sqrt(pow(b[i].x-a2.x,2)+pow(b[i].y-a2.y,2))<20){
            b[i].y=a2.y;
            b[i].x=a2.x;
        }
    }
}

/*void clash(struct Barrack s[],int a) {
    for (int i = 0; i < 30; i++)
        if (sol[i].tu)
            for (int k = 0; k < sol[i].m; k++)
                if (s[a].type != sol[i].s[k].type) {
                    if (sqrt(pow(sol[i].s[k].x - s[a].x, 2) + pow(sol[i].s[k].y - s[a].y, 2)) < 12) {
                        sol[i].s[k].type = EMPTY_TYPE;
                        s[a].type = EMPTY_TYPE;
                        printf("ok %d\n",a);
                    }
                } else {
                    break;
                }
}*/
bool move(struct Barrack s[],int q1,int q2,int *m,int *k,int *h,int Y){
    if(*m==0)
        *h = level.barracks[q1].soldier;

    create_solder(level.barracks[q1], s, *m);

    bool on=OFF;
    int B=120;
    if(level.barracks[q1].Potion==1)
       B-=50;

    for (int i = 0; i < level.barracksCount; i++) {
       if(level.barracks[i].type!=level.barracks[q1].type && level.barracks[i].Potion==2) {
           B -= 50;
           break;
       }
    }
    if (check_time(sol[Y].time, B)) {
        on = ON;
        sol[Y].time = SDL_GetTicks();
    }
   /*if(s[0ype==ENEMY_TYPE) {
       B=false;
       if (check_time(pppp, 50)) {
           B = true;
           pppp = SDL_GetTicks();
       }
   }
   bool harkat=false;
   if(level.barracks[q1].type==ENEMY_TYPE) {
       if (check_time(eeee, B)) {
           eeee = SDL_GetTicks();
           harkat = true;
       }
   }
   else{
       if (check_time(pppp, B)) {
           pppp = SDL_GetTicks();
           harkat = true;
       }
   }*/
    /*bool B=false;
    if(level.barracks[q1].type==ENEMY_TYPE) {
        if (check_time(s[*m].time_solder, B)) {
            B = true;
            pppp = SDL_GetTicks();
        }
    }else{
        if (check_time(eeee, 150)) {
            B = true;
            eeee = SDL_GetTicks();
        }
    }*/

    if(on) {
        if(*m<*h) {
            level.barracks[q1].soldier--;
            (*m)++;
        }

        move_solder(level.barracks[q1], level.barracks[q2], s, *m);

        int fx = level.barracks[q2].x - s[*k].x, fy = level.barracks[q2].y - s[*k].y;
        if (fx < 0)fx *= -1;
        if (fy < 0)fy *= -1;

        //clash(s,*k);
        if (10 > fx && 10 > fy) {
            if (s[*k].type != EMPTY_TYPE) {
                if (s[*k].type == level.barracks[q2].type)
                    level.barracks[q2].soldier++;
                else {
                    level.barracks[q2].soldier--;
                }
            }
            if (level.barracks[q2].soldier <= 0) {
                level.barracks[q2].soldier = 1;
                level.barracks[q2].type = level.barracks[q1].type;
                level.barracks[q2].Potion=level.barracks[q1].Potion;
                level.barracks[q2].start_potion=level.barracks[q1].start_potion;
            }
            (*k)++;
        }
    }
    show_solder(s, *m);
    if(*k==*h)
        return OFF;
    else
        return ON;
}
bool choice(int *p,int *m,int *k,bool *u,int *q1,int *q2,int q){
    if (*p == 1) {
        *q1 = q;
        if (level.barracks[*q1].type!=MY_TYPE)
            *p = 0;
        else
            *u = true;
    } else if (*p == 2) {
        *q2 = q;
        *p = 0;
        *u = false;
        *m = 0;
        *k = 0;
        if (*q1 != *q2)
            return ON;
    }
    return OFF;
}

/*************************************************************/
/*
void create_solder(int o){
    sol[o].s[sol[o].m].x=level.barracks[sol[o].q1].x;
    sol[o].s[sol[o].m].y=level.barracks[sol[o].q1].y;
    sol[o].s[sol[o].m].type=level.barracks[sol[o].q1].type;
    if(sol[o].m==0)
        sol[o].count_solder = level.barracks[sol[o].q1].soldier;
}
void show_solder(int o){
    int h;
    for (int i = 0; i < sol[o].m; i++) {
        switch (sol[o].s[i].type) {
            case BLANK_TYPE:h = 0;break;
            case ENEMY_TYPE:h = 1;break;
            case MY_TYPE:h = 2;break;
        }
        Sint16 x = sol[o].s[i].x, y = sol[o].s[i].y, r = 6;
        if(sol[o].s[i].type!=EMPTY_TYPE)
            filledCircleColor(renderer, x, y, r, colors[h]);
    }
}/*
void move_solder(struct Barrack a,struct Barrack a2,struct Barrack b[],int m){
    for (int i = 0; i < m; i++) {
        int fx=a.x-a2.x,fy=a.y-a2.y;
        if(fx<0)fx*=-1;
        if(fy<0)fy*=-1;
        if(100<fx || 50>fy) {
            if (b[i].x != a2.x) {
                if (b[i].x < a2.x)
                    b[i].x += 10;
                else
                    b[i].x -= 10;
                int d = (a.y - a2.y), d2 = (a.x - a2.x);
                double m = (double) d / (double) d2;
                b[i].y = m * (b[i].x - a.x) + a.y;
            }
        }
        else{
            if (b[i].y != a2.y) {
                if (b[i].y < a2.y)
                    b[i].y += 10;
                else
                    b[i].y -= 10;
                int d = (a.y - a2.y), d2 = (a.x - a2.x);
                double m = (double) d / (double) d2;
                double f=(double)(b[i].y-a.y)/m;
                b[i].x=f+ a.x;
            }
        }
    }
}*/

/*
bool move_f(int o){
    int fx=level.barracks[sol[o].q2].x-sol[o].s[sol[o].k].x,fy=level.barracks[sol[o].q2].y-sol[o].s[sol[o].k].y;
    if(fx<0)fx*=-1;
    if(fy<0)fy*=-1;
    if(20>fx && 20>fy)
        return true;
    if(level.barracks[sol[o].q2].x==sol[o].s[sol[o].k].x && level.barracks[sol[o].q2].y==sol[o].s[sol[o].k].y)
        return true;
    return false;
}

bool move(int o){
    create_solder(o);
    //printf("q1 : %d & q2 : %d & o:%d & type:%d\n",sol[o].q1,sol[o].q2,o,sol[o].s[0].type);
    bool B=true;
    if(sol[o].s[0].type==ENEMY_TYPE) {
        B=false;
        if (check_time(gsdf, 80)) {
            B = true;
            gsdf = SDL_GetTicks();
        }
    }
    if(B==true) {
        if (sol[o].m < sol[o].count_solder) {
            level.barracks[sol[o].q1].soldier--;
            (sol[o].m)++;
        }
        move_solder(level.barracks[sol[o].q1], level.barracks[sol[o].q2], sol[o].s, sol[o].m);

        if (move_f(o)) {
            if (sol[o].s[sol[o].k].type != EMPTY_TYPE) {
                if (level.barracks[sol[o].q1].type == level.barracks[sol[o].q2].type)
                    level.barracks[sol[o].q2].soldier++;
                else
                    level.barracks[sol[o].q2].soldier--;
            } else
                printf("sol[o].k: %d && o:%d\n",sol[o].k,o);
            if (level.barracks[sol[o].q2].soldier <= 0) {
                level.barracks[sol[o].q2].soldier = 1;
                level.barracks[sol[o].q2].type = level.barracks[sol[o].q1].type;
            }
            sol[o].k++;
        }
    }
    show_solder(o);
    if(sol[o].k==sol[o].count_solder)
        return OFF;
    else
        return ON;
}
bool choice(int *p,bool *u,int o,int q){
    if (*p == 1) {
        sol[o].q1 = q;
        //printf("Q1 %d & o:%d\n",sol[o].q1,o);
        if (level.barracks[sol[o].q1].type!=MY_TYPE)
            *p = 0;
        else
            *u = true;
    } else if (*p == 2) {
        sol[o].q2 = q;
        //printf("Q2 %d & o:%d \n",sol[o].q2,o);
        *p = 0;
        *u = false;
        sol[o].m = 0;
        sol[o].k = 0;
        if (sol[o].q1 != sol[o].q2)
            return ON;
    }
    return OFF;
}*/
#endif //C_PROJECT_SOLDERS_H
