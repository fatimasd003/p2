
#ifndef C_PROJECT_WIN_OR_LOSE_H
#define C_PROJECT_WIN_OR_LOSE_H

#include "my_struct.h"
#include <stdbool.h>
bool win(){
    for (int i = 0; i < level.barracksCount; i++)
        if(level.barracks[i].type==ENEMY_TYPE)
            return false;
    return true;
}
bool Lose(){
    for (int i = 0; i < level.barracksCount; i++)
        if(level.barracks[i].type==MY_TYPE)
            return false;
    return true;
}
bool not_win_or_lose(){
    if(!win() && !Lose())
        return true;
    return false;
}

#endif //C_PROJECT_WIN_OR_LOSE_H
